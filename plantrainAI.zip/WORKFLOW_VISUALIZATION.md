# 📊 WORKFLOW VISUALIZATION - LIVE TRADING

**Version:** 2.0.0 (Nov 21, 2025)
**Major Update:** FVG-only Signal với Strength, Retest Geometry, Adaptive Entry

---

## ⚠️ CRITICAL DESIGN DECISIONS (Nov 2025)

### 1. FVG is the ONLY Signal Type
- **FVG retest is the ONLY signal type** - OB/CHoCH provide context ONLY
- Model learns: `FVG retest → long/short/skip`

### 2. Layer Distribution
| Layer | Responsibility |
|-------|---------------|
| **Layer 1 (Ninja)** | RAW detection ONLY - FVG boundaries, OHLCV, volume, delta |
| **Layer 2 (Python)** | ALL quality logic - Strength, Penetration, Rebalance, Entry |

### 3. FVG Quality Components (Module #2 v2.0)
```
FVG Quality Assessment:
├─ 1. FVG STRENGTH (size, volume, delta, rebalance)
├─ 2. RETEST GEOMETRY (penetration ratio, touch type)
├─ 3. REBALANCE DETECTION (fills previous FVG?)
└─ 4. ADAPTIVE ENTRY (dynamic buffer based on strength)
```

---

## 🎯 TABLE OF CONTENTS

1. [Training Mode Workflow](#training-mode-workflow)
2. [FVG Processing Deep Dive](#fvg-processing-deep-dive)
3. [Live Trading Workflow](#live-trading-workflow)
4. [Data Flow Diagrams](#data-flow-diagrams)
5. [Component Interactions](#component-interactions)
6. [Real-time vs Batch Processing](#real-time-vs-batch-processing)

---

## 📚 TRAINING MODE WORKFLOW

### PHASE 1: Data Collection (Offline)

```
┌─────────────────────────────────────────────────────────────────┐
│                    NINJATRADER (HISTORICAL)                      │
│                                                                   │
│  ┌──────────────────────────────────────────────────────────┐  │
│  │  SMC_Structure_Lightweight Indicator                      │  │
│  │  - Detect OB/FVG/CHoCH                                    │  │
│  │  - NO scoring, NO filtering                              │  │
│  │  - Just RAW detection                                     │  │
│  └────────────────────┬─────────────────────────────────────┘  │
│                       │                                          │
│  ┌────────────────────▼─────────────────────────────────────┐  │
│  │  Volumdelta Indicator                                     │  │
│  │  - Calculate buy/sell volume                             │  │
│  │  - Delta per bar                                          │  │
│  │  - Cumulative delta                                       │  │
│  └────────────────────┬─────────────────────────────────────┘  │
│                       │                                          │
│  ┌────────────────────▼─────────────────────────────────────┐  │
│  │  SMC_RawExporter                                          │  │
│  │  - Combine data from both indicators                      │  │
│  │  - Export as JSONL (1 line per bar)                      │  │
│  │  - Save to file                                           │  │
│  └────────────────────┬─────────────────────────────────────┘  │
└───────────────────────┼──────────────────────────────────────────┘
                        │
                        │ raw_smc_export.jsonl
                        │ ┌──────────────────────────────────┐
                        │ │ {"time": "2025-11-20T10:00:00Z", │
                        │ │  "o": 1.2330, "h": 1.2340, ...   │
                        │ │  "ob_detected": true,             │
                        │ │  "ob_high": 1.2340,               │
                        │ │  "ob_low": 1.2320,                │
                        │ │  "volume": 1250,                  │
                        │ │  "buy_vol": 750,                  │
                        │ │  "sell_vol": 500}                 │
                        │ └──────────────────────────────────┘
                        ▼
```

### PHASE 2: Data Processing (Offline)

```
┌─────────────────────────────────────────────────────────────────┐
│                    PYTHON PROCESSOR                              │
│                                                                   │
│  ┌──────────────────────────────────────────────────────────┐  │
│  │  SMCDataProcessor - Module Execution Order               │  │
│  │                                                            │  │
│  │  Step 1: Foundation Modules                                │  │
│  │  ┌────────────────┐  ┌────────────────┐                  │  │
│  │  │ Fix #9         │  │ Fix #11        │                  │  │
│  │  │ Volume Profile │  │ Liquidity Map  │                  │  │
│  │  │ VAH/VAL/POC    │  │ Sweep detect   │                  │  │
│  │  └────────────────┘  └────────────────┘                  │  │
│  │                                                            │  │
│  │  Step 2: Context Modules                                  │  │
│  │  ┌────────────────┐  ┌────────────────┐  ┌────────────┐ │  │
│  │  │ Fix #1         │  │ Fix #7         │  │ Fix #8     │ │  │
│  │  │ OB Quality     │  │ Market Cond    │  │ Vol Div    │ │  │
│  │  │ (OB=context)   │  │ Score: 0.88    │  │ Score: 0.6 │ │  │
│  │  └────────────────┘  └────────────────┘  └────────────┘ │  │
│  │                                                            │  │
│  │  Step 3: FVG Quality (CORE - v2.0)                        │  │
│  │  ┌──────────────────────────────────────────────────────┐│  │
│  │  │ Fix #2: FVG Quality Module (4 components)            ││  │
│  │  │ ┌─────────────┐ ┌─────────────┐ ┌─────────────────┐ ││  │
│  │  │ │ FVG Strength│ │ Rebalance   │ │ Component Scores│ ││  │
│  │  │ │ size_atr    │ │ Detection   │ │ gap_quality     │ ││  │
│  │  │ │ vol_ratio   │ │ fills prev? │ │ vol_quality     │ ││  │
│  │  │ │ delta_ratio │ │ clean?      │ │ imbalance_qual  │ ││  │
│  │  │ │ alignment   │ │             │ │                 │ ││  │
│  │  │ └─────────────┘ └─────────────┘ └─────────────────┘ ││  │
│  │  │ Output: fvg_strength_class = "Strong/Medium/Weak"    ││  │
│  │  └──────────────────────────────────────────────────────┘│  │
│  │                                                            │  │
│  │  Step 4: Confluence                                       │  │
│  │  ┌────────────────┐                                       │  │
│  │  │ Fix #4         │                                       │  │
│  │  │ Confluence     │                                       │  │
│  │  │ Score: 78.5    │                                       │  │
│  │  └────────────────┘                                       │  │
│  └────────────────────┬─────────────────────────────────────┘  │
└─────────────────────┼──────────────────────────────────────────┘
                      │
                      │ bar_states.jsonl
                      │ ┌──────────────────────────────────────┐
                      │ │ {"time": "2025-11-20T10:00:00Z",     │
                      │ │  // FVG Quality v2.0 fields          │
                      │ │  "fvg_strength_score": 0.88,         │
                      │ │  "fvg_strength_class": "Strong",     │
                      │ │  "fvg_rebalances_prev": true,        │
                      │ │  "fvg_is_clean_rebalance": true,     │
                      │ │  "fvg_value_class": "A",             │
                      │ │  // OB as context                    │
                      │ │  "ob_strength_score": 0.85,          │
                      │ │  "confluence_score": 78.5,            │
                      │ │  ...}                                 │
                      │ └──────────────────────────────────────┘
                      ▼
```

### PHASE 3: Event Detection - FVG RETEST ONLY (Offline)

```
┌─────────────────────────────────────────────────────────────────┐
│              FVG EVENT DETECTOR (FVG Retest ONLY)                │
│                                                                   │
│  For each active FVG zone, detect retest:                        │
│                                                                   │
│  ┌───────────────────────────────────────────────────────────┐  │
│  │  FVG Zone: Bull FVG at [1.2330, 1.2350]                   │  │
│  │  Strength: "Strong" (score: 0.88)                          │  │
│  │  Rebalances prev: True (clean)                             │  │
│  └───────────────────────────────────────────────────────────┘  │
│                         │                                         │
│  Bar 105: price comes down to test FVG                           │
│           Low = 1.2348 (just touched top edge)                   │
│           │                                                       │
│           ▼                                                       │
│  ┌───────────────────────────────────────────────────────────┐  │
│  │  RETEST GEOMETRY EVALUATION (Module #2 v2.0)              │  │
│  │  ├─ penetration_ratio = 0.10 (10%)                        │  │
│  │  ├─ touch_type = "edge" ✅ BEST                           │  │
│  │  ├─ front_run_distance = 0.0                              │  │
│  │  └─ retest_quality_score = 0.95 ⭐                        │  │
│  └───────────────────────────────────────────────────────────┘  │
│           │                                                       │
│           ▼                                                       │
│  ┌───────────────────────────────────────────────────────────┐  │
│  │  VALIDATION CHECKS:                                        │  │
│  │  ├─ fvg_strength_class = "Strong"? ✅                     │  │
│  │  ├─ penetration_ratio < 0.50? ✅ (0.10)                   │  │
│  │  ├─ retest_quality > 0.60? ✅ (0.95)                      │  │
│  │  ├─ market_condition > 0.7? ✅                            │  │
│  │  ├─ session = London? ✅                                  │  │
│  │  └─ ✅ CREATE FVG RETEST EVENT                            │  │
│  └───────────────────────────────────────────────────────────┘  │
│           │                                                       │
│           ▼                                                       │
│  ┌───────────────────────────────────────────────────────────┐  │
│  │  ADAPTIVE ENTRY CALCULATION:                               │  │
│  │  FVG Strength = "Strong" →                                 │  │
│  │  ├─ buffer_ratio = 10%                                    │  │
│  │  ├─ allow_front_run = True                                │  │
│  │  ├─ entry_ideal = 1.2350 (FVG edge)                       │  │
│  │  ├─ entry_real = 1.2352 (with buffer)                     │  │
│  │  └─ RR_real = 2.8 (slightly lower than ideal 3.2)         │  │
│  └───────────────────────────────────────────────────────────┘  │
│                                                                   │
│  ❌ REJECTED EXAMPLES:                                            │
│  Bar 115: penetration = 0.65 (65%) → "deep" → SKIP               │
│  Bar 120: fvg_strength = "Weak" → SKIP                           │
│  Bar 125: retest_quality < 0.30 → SKIP                           │
│                                                                   │
└────────────────────┬────────────────────────────────────────────┘
                     │
                     │ event_states.jsonl (FVG RETEST ONLY!)
                     │ ┌────────────────────────────────────────┐
                     │ │ {"signal_type": "fvg_retest_bull",     │
                     │ │  "direction": 1,                        │
                     │ │  // FVG Quality                         │
                     │ │  "fvg_strength_class": "Strong",        │
                     │ │  "fvg_rebalances_prev": true,           │
                     │ │  // Retest Geometry                     │
                     │ │  "fvg_retest_type": "edge",             │
                     │ │  "fvg_penetration_ratio": 0.10,         │
                     │ │  "fvg_retest_quality_score": 0.95,      │
                     │ │  // Adaptive Entry                      │
                     │ │  "entry_price_ideal": 1.2350,           │
                     │ │  "entry_price_real": 1.2352,            │
                     │ │  "rr_ideal": 3.2,                       │
                     │ │  "rr_real": 2.8,                        │
                     │ │  // OB Context (NOT signal)             │
                     │ │  "has_ob_in_leg": true,                 │
                     │ │  "ob_strength_score": 0.85,             │
                     │ │  // Final                               │
                     │ │  "signal": "long"}                      │
                     │ └────────────────────────────────────────┘
                     ▼
```

### PHASE 4: ML Training (Offline)

```
┌─────────────────────────────────────────────────────────────────┐
│                    ML TRAINING PIPELINE                          │
│                                                                   │
│  ┌──────────────────────────────────────────────────────────┐  │
│  │  Labeling Strategy (Option A/B/C)                         │  │
│  │  - Convert EventState to training format                  │  │
│  │  - Apply labeling logic                                   │  │
│  │  - Create train/val split                                 │  │
│  └────────────────────┬─────────────────────────────────────┘  │
│                       │                                          │
│  ┌────────────────────▼─────────────────────────────────────┐  │
│  │  DeepSeek Model Training                                  │  │
│  │  - Load train.jsonl                                       │  │
│  │  - Train with class weights                               │  │
│  │  - Validate on val.jsonl                                  │  │
│  │  - Save checkpoint                                         │  │
│  └────────────────────┬─────────────────────────────────────┘  │
└─────────────────────┼──────────────────────────────────────────┘
                      │
                      │ model_checkpoint.pt
                      ▼
```

---

## 🎯 FVG PROCESSING DEEP DIVE (v2.0)

### FVG Quality Decision Tree

```
┌─────────────────────────────────────────────────────────────────┐
│                    FVG QUALITY DECISION TREE                     │
│                                                                   │
│  FVG Detected (raw from Ninja)                                   │
│  │                                                               │
│  ├─► Calculate STRENGTH                                          │
│  │   ├─ size_atr = gap_size / ATR                                │
│  │   ├─ vol_ratio = volume / median_20                           │
│  │   ├─ delta_ratio = |delta| / volume                           │
│  │   └─ delta_alignment = matches FVG direction?                 │
│  │                                                               │
│  │   ┌─────────────────────────────────────────────────────┐    │
│  │   │ STRENGTH CLASSIFICATION:                             │    │
│  │   │                                                      │    │
│  │   │ STRONG: size_atr ≥ 1.5 AND vol_ratio ≥ 2.0          │    │
│  │   │         AND delta_ratio ≥ 0.6 AND aligned           │    │
│  │   │         → Allow front-run, tight buffer              │    │
│  │   │                                                      │    │
│  │   │ MEDIUM: size_atr ≥ 0.8 AND vol_ratio ≥ 1.3          │    │
│  │   │         → Wait for touch, moderate buffer            │    │
│  │   │                                                      │    │
│  │   │ WEAK:   Below thresholds                             │    │
│  │   │         → SKIP or very wide buffer                   │    │
│  │   └─────────────────────────────────────────────────────┘    │
│  │                                                               │
│  ├─► Check REBALANCE                                             │
│  │   │                                                           │
│  │   │  Does this FVG's creation leg fill a previous FVG?        │
│  │   │  ├─ YES, >80% filled → "Clean Rebalance" ⭐ BONUS        │
│  │   │  ├─ YES, 30-80% filled → "Partial Rebalance"             │
│  │   │  └─ NO → Normal FVG                                       │
│  │                                                               │
│  └─► Assign VALUE CLASS                                          │
│      │                                                           │
│      │  ┌─────────────────────────────────────────────────┐     │
│      │  │ CLASS A: Strong + (rebalance OR after_sweep)    │     │
│      │  │          → HIGHEST PRIORITY, best setups        │     │
│      │  │                                                  │     │
│      │  │ CLASS B: Strong (no bonus) OR Medium + bonus    │     │
│      │  │          → GOOD, acceptable setups              │     │
│      │  │                                                  │     │
│      │  │ CLASS C: Medium (no bonus) OR Weak              │     │
│      │  │          → SKIP in most cases                   │     │
│      │  └─────────────────────────────────────────────────┘     │
│                                                                   │
└─────────────────────────────────────────────────────────────────┘
```

### Retest Geometry Decision Tree

```
┌─────────────────────────────────────────────────────────────────┐
│                    RETEST GEOMETRY EVALUATION                    │
│                                                                   │
│  Price approaches FVG zone                                        │
│  │                                                               │
│  ├─► Calculate PENETRATION RATIO                                 │
│  │   │                                                           │
│  │   │  Bull FVG: penetration = (fvg_high - bar_low) / fvg_size │
│  │   │  Bear FVG: penetration = (bar_high - fvg_low) / fvg_size │
│  │   │                                                           │
│  │   │  ┌─────────────────────────────────────────────────┐     │
│  │   │  │ TOUCH TYPE CLASSIFICATION:                       │     │
│  │   │  │                                                  │     │
│  │   │  │ no_touch  (ratio = 0.0)    → Front-run zone     │     │
│  │   │  │ edge      (ratio ≤ 0.20)   → ⭐ BEST quality    │     │
│  │   │  │ shallow   (ratio 0.20-0.50) → OK quality        │     │
│  │   │  │ deep      (ratio 0.50-1.00) → ⚠️ RISKY         │     │
│  │   │  │ break     (ratio > 1.00)    → ❌ INVALID        │     │
│  │   │  └─────────────────────────────────────────────────┘     │
│  │                                                               │
│  └─► QUALITY MATRIX (Strength × Touch Type):                     │
│                                                                   │
│      ┌────────────┬─────────┬─────────┬─────────┬─────────┐     │
│      │            │no_touch │  edge   │ shallow │  deep   │     │
│      ├────────────┼─────────┼─────────┼─────────┼─────────┤     │
│      │ STRONG     │  0.80   │  0.95 ⭐│  0.60   │  0.25   │     │
│      │ MEDIUM     │  0.20   │  0.75   │  0.40   │  0.10   │     │
│      │ WEAK       │  0.10   │  0.50   │  0.20   │  SKIP   │     │
│      └────────────┴─────────┴─────────┴─────────┴─────────┘     │
│                                                                   │
│      Rule: "Strong FVG + Edge touch = BEST setup (0.95)"         │
│      Rule: "Any FVG + Deep penetration = RISKY, likely SKIP"     │
│                                                                   │
└─────────────────────────────────────────────────────────────────┘
```

### Adaptive Entry Decision Tree

```
┌─────────────────────────────────────────────────────────────────┐
│                    ADAPTIVE ENTRY CALCULATION                    │
│                                                                   │
│  Given: FVG zone, strength_class, retest_type                    │
│  │                                                               │
│  ├─► BUFFER SIZE based on strength:                              │
│  │                                                               │
│  │   STRONG: buffer = 10% of FVG OR 0.15 ATR (whichever larger) │
│  │   MEDIUM: buffer = 20% of FVG OR 0.25 ATR                     │
│  │   WEAK:   buffer = 30% of FVG OR 0.35 ATR                     │
│  │                                                               │
│  ├─► ENTRY PRICES:                                               │
│  │                                                               │
│  │   Bull FVG (long):                                            │
│  │   ├─ entry_ideal = fvg_high (edge)                            │
│  │   ├─ entry_50pct = (fvg_high + fvg_low) / 2                   │
│  │   └─ entry_real  = fvg_high + buffer (conservative)           │
│  │                                                               │
│  │   Bear FVG (short):                                           │
│  │   ├─ entry_ideal = fvg_low (edge)                             │
│  │   ├─ entry_50pct = (fvg_high + fvg_low) / 2                   │
│  │   └─ entry_real  = fvg_low - buffer (conservative)            │
│  │                                                               │
│  └─► RR COMPARISON:                                              │
│                                                                   │
│      Example: Bull FVG [1.2330, 1.2350], SL below at 1.2310      │
│                                                                   │
│      entry_ideal = 1.2350 → risk = 40 ticks → RR = 3.2           │
│      entry_real  = 1.2352 → risk = 42 ticks → RR = 2.8           │
│                                                                   │
│      rr_degradation = 3.2 - 2.8 = 0.4 (acceptable)               │
│                                                                   │
│      ⚠️ If rr_degradation > 1.0 → reconsider entry strategy      │
│                                                                   │
└─────────────────────────────────────────────────────────────────┘
```

### Complete FVG Event Flow

```
┌─────────────────────────────────────────────────────────────────┐
│             COMPLETE FVG EVENT FLOW (From Raw to Signal)         │
│                                                                   │
│  ═══════════════════════════════════════════════════════════     │
│  LAYER 1: NINJATRADER (RAW ONLY)                                │
│  ═══════════════════════════════════════════════════════════     │
│                                                                   │
│  Bar N: FVG detected                                              │
│  Export: {                                                        │
│    "fvg_detected": true,                                         │
│    "fvg_type": "bullish",                                        │
│    "fvg_high": 1.2350,                                           │
│    "fvg_low": 1.2330,                                            │
│    "volume": 2500,                                               │
│    "buy_volume": 2000,                                           │
│    "sell_volume": 500,                                           │
│    "delta": 1500                                                 │
│  }                                                               │
│                         │                                         │
│  ═══════════════════════▼═══════════════════════════════════     │
│  LAYER 2: PYTHON PROCESSOR                                       │
│  ═══════════════════════════════════════════════════════════     │
│                         │                                         │
│  ┌──────────────────────▼──────────────────────────────────┐    │
│  │ Module #2: FVG QUALITY (process_bar)                     │    │
│  │                                                          │    │
│  │ 1. Calculate strength metrics                            │    │
│  │    size_atr = 0.02 / 0.00025 = 1.6 ATR ✓                │    │
│  │    vol_ratio = 2500 / 1100 = 2.27 ✓                      │    │
│  │    delta_ratio = 1500 / 2500 = 0.60 ✓                    │    │
│  │    delta_alignment = +1 (bull FVG + pos delta) ✓         │    │
│  │                                                          │    │
│  │ 2. Classify: fvg_strength_class = "Strong"               │    │
│  │                                                          │    │
│  │ 3. Check rebalance: fvg_rebalances_prev = true           │    │
│  │                                                          │    │
│  │ 4. Assign: fvg_value_class = "A" ⭐                      │    │
│  │                                                          │    │
│  │ Output: BarState with FVG quality fields                 │    │
│  └──────────────────────┬──────────────────────────────────┘    │
│                         │                                         │
│  ... 15 bars later ...                                           │
│                         │                                         │
│  ┌──────────────────────▼──────────────────────────────────┐    │
│  │ EVENT DETECTOR: FVG Retest Detection                     │    │
│  │                                                          │    │
│  │ Bar N+15: price_low = 1.2348 (near FVG top)              │    │
│  │                                                          │    │
│  │ 1. Detect retest of FVG zone [1.2330, 1.2350]            │    │
│  │                                                          │    │
│  │ 2. Evaluate geometry (Module #2.evaluate_retest)         │    │
│  │    penetration = (1.2350 - 1.2348) / 0.002 = 0.10 (10%) │    │
│  │    touch_type = "edge" ✓                                 │    │
│  │    retest_quality = 0.95 ⭐                              │    │
│  │                                                          │    │
│  │ 3. Validate:                                             │    │
│  │    strength = "Strong" ✓                                 │    │
│  │    penetration < 0.50 ✓                                  │    │
│  │    quality > 0.60 ✓                                      │    │
│  │                                                          │    │
│  │ 4. Calculate adaptive entry:                             │    │
│  │    buffer = 10% of FVG = 0.0002                          │    │
│  │    entry_real = 1.2352                                   │    │
│  │    rr_real = 2.8                                         │    │
│  │                                                          │    │
│  │ 5. Create EventState with all fields                     │    │
│  └──────────────────────┬──────────────────────────────────┘    │
│                         │                                         │
│  ═══════════════════════▼═══════════════════════════════════     │
│  OUTPUT: EventState                                              │
│  ═══════════════════════════════════════════════════════════     │
│                                                                   │
│  {                                                               │
│    "signal_type": "fvg_retest_bull",                             │
│    "fvg_strength_class": "Strong",                               │
│    "fvg_retest_type": "edge",                                    │
│    "fvg_penetration_ratio": 0.10,                                │
│    "entry_price_real": 1.2352,                                   │
│    "rr_real": 2.8,                                               │
│    "signal": "long"                                              │
│  }                                                               │
│                                                                   │
└─────────────────────────────────────────────────────────────────┘
```

---

## 🔴 LIVE TRADING WORKFLOW

### OPTION 1: Real-time Processing (Fully Automated)

```
TIME: Market is LIVE, bars forming in real-time

┌─────────────────────────────────────────────────────────────────┐
│                    NINJATRADER (LIVE CHART)                      │
│                      Every 1 minute (M1 bar)                     │
│                                                                   │
│  10:30:00 - New Bar Starts                                       │
│  10:30:59 - Bar About to Close                                   │
│  10:31:00 - Bar Closes (OnBarClose)                              │
│            │                                                      │
│            ▼                                                      │
│  ┌──────────────────────────────────────────────────────────┐  │
│  │  SMC_Structure_Lightweight                                │  │
│  │  - Check: OB detected? YES                                │  │
│  │  - Store: ob_high, ob_low, volume                         │  │
│  └────────────────────┬─────────────────────────────────────┘  │
│                       │                                          │
│  ┌────────────────────▼─────────────────────────────────────┐  │
│  │  Volumdelta                                                │  │
│  │  - Calculate: buy_vol=750, sell_vol=500                   │  │
│  └────────────────────┬─────────────────────────────────────┘  │
│                       │                                          │
│  ┌────────────────────▼─────────────────────────────────────┐  │
│  │  SMC_RealTimeProcessor (New C# Indicator)                 │  │
│  │                                                            │  │
│  │  LIGHTWEIGHT logic embedded:                              │  │
│  │  ├─ Quick OB score check (simplified)                     │  │
│  │  ├─ Volume factor > 2.0? YES                              │  │
│  │  ├─ Delta imbalance > 0.5? YES                            │  │
│  │  ├─ Session = London? YES                                 │  │
│  │  └─ Estimated confluence > 70? YES                        │  │
│  │                                                            │  │
│  │  ✅ SIGNAL TRIGGERED!                                     │  │
│  │                                                            │  │
│  │  Action:                                                   │  │
│  │  1. Call ML Model API                                     │  │
│  │  2. Get prediction: "long"                                │  │
│  │  3. Place order via NinjaTrader                           │  │
│  │                                                            │  │
│  │  OR:                                                       │  │
│  │                                                            │  │
│  │  1. Send alert to Telegram                                │  │
│  │  2. Manual review                                         │  │
│  │  3. Manual order                                          │  │
│  └────────────────────────────────────────────────────────────┘  │
└─────────────────────────────────────────────────────────────────┘

   PROS:
   ✅ Fully automated
   ✅ Fast (sub-second response)
   ✅ No Python needed live

   CONS:
   ❌ Simplified scoring (less accurate)
   ❌ C# complexity (harder to maintain)
```

### OPTION 2: Hybrid Approach (Semi-automated) ⭐ RECOMMENDED

```
TIME: Market is LIVE

┌─────────────────────────────────────────────────────────────────┐
│               NINJATRADER (LIVE CHART) - LAYER 1                 │
│                                                                   │
│  10:31:00 - Bar Closes                                           │
│            │                                                      │
│  ┌─────────▼────────────────────────────────────────────────┐  │
│  │  SMC_RawExporter (Ultra-lightweight)                      │  │
│  │  - Export raw data ONLY                                   │  │
│  │  - Write to: live_stream.jsonl                            │  │
│  │  - NO processing, NO scoring                              │  │
│  └────────────────────────────────────────────────────────────┘  │
└───────────────────┬──────────────────────────────────────────────┘
                    │
                    │ live_stream.jsonl (append mode)
                    │ {"time": "2025-11-20T10:31:00Z", ...}
                    ▼
┌─────────────────────────────────────────────────────────────────┐
│            PYTHON PROCESSOR (LIVE SERVICE) - LAYER 2             │
│            Running in background, monitoring file                 │
│                                                                   │
│  ┌──────────────────────────────────────────────────────────┐  │
│  │  File Watcher (or Polling every 1 second)                 │  │
│  │  - Detect new line in live_stream.jsonl                   │  │
│  │  - Read new bar data                                      │  │
│  └────────────────────┬─────────────────────────────────────┘  │
│                       │                                          │
│  ┌────────────────────▼─────────────────────────────────────┐  │
│  │  SMCDataProcessor                                         │  │
│  │  - Process bar (all 10 modules)                           │  │
│  │  - Calculate all scores                                   │  │
│  │  - Full quality check                                     │  │
│  │  - Takes ~50-100ms                                        │  │
│  └────────────────────┬─────────────────────────────────────┘  │
│                       │                                          │
│  ┌────────────────────▼─────────────────────────────────────┐  │
│  │  Event Detection                                          │  │
│  │  - confluence_score = 85.2                                │  │
│  │  - confluence > 70? YES ✅                                │  │
│  │  - market_condition_score > 0.7? YES ✅                   │  │
│  │  - session OK? YES ✅                                     │  │
│  │                                                            │  │
│  │  📢 TRADING SIGNAL DETECTED!                              │  │
│  └────────────────────┬─────────────────────────────────────┘  │
│                       │                                          │
│  ┌────────────────────▼─────────────────────────────────────┐  │
│  │  Signal Handler                                           │  │
│  │                                                            │  │
│  │  OPTION A: Auto-trade                                     │  │
│  │  ├─ Call ML model                                         │  │
│  │  ├─ Get prediction                                        │  │
│  │  ├─ Send order via NinjaTrader API                        │  │
│  │  └─ Log trade                                             │  │
│  │                                                            │  │
│  │  OPTION B: Alert only                                     │  │
│  │  ├─ Send Telegram message                                 │  │
│  │  ├─ Include: signal, scores, chart link                   │  │
│  │  └─ Wait for manual confirmation                          │  │
│  │                                                            │  │
│  │  OPTION C: Dashboard                                      │  │
│  │  └─ Update web dashboard with signal                      │  │
│  └────────────────────────────────────────────────────────────┘  │
└─────────────────────────────────────────────────────────────────┘

   PROS:
   ✅ Full scoring accuracy
   ✅ Easy to maintain (Python)
   ✅ Can update modules without recompiling
   ✅ Still fast enough (<200ms total)
   ✅ Can review before trading

   CONS:
   ⚠️  Need Python service running
   ⚠️  Slight delay (~100ms)
```

### OPTION 3: Batch Processing (Manual Trading)

```
TIME: End of trading session or every 5 minutes

┌─────────────────────────────────────────────────────────────────┐
│                    NINJATRADER (LIVE CHART)                      │
│  - Export raw data continuously                                  │
│  - File: live_stream.jsonl (growing)                            │
└───────────────────┬──────────────────────────────────────────────┘
                    │
                    │ Every 5 minutes:
                    ▼
┌─────────────────────────────────────────────────────────────────┐
│                    PYTHON PROCESSOR                              │
│  1. Read last 100 bars from live_stream.jsonl                   │
│  2. Process all bars                                             │
│  3. Detect events                                                │
│  4. Generate report:                                             │
│     - 3 signals detected                                         │
│     - Signal 1: OB bull, confluence 88.5                         │
│     - Signal 2: FVG bull, confluence 75.2                        │
│     - Signal 3: OB bear, confluence 82.0                         │
│  5. Send report to Telegram                                      │
│  6. Trader reviews and acts manually                             │
└─────────────────────────────────────────────────────────────────┘

   PROS:
   ✅ Simple architecture
   ✅ Full control (manual trading)
   ✅ No real-time pressure

   CONS:
   ❌ May miss fast signals
   ❌ Requires manual action
```

---

## 📈 DETAILED DATA FLOW DIAGRAM

### Complete System (Training + Live)

```
╔═════════════════════════════════════════════════════════════════╗
║                         HISTORICAL DATA                          ║
╚═════════════════════════════════════════════════════════════════╝
                            │
                            ▼
        ┌───────────────────────────────────────┐
        │   NinjaTrader Replay / Historical     │
        │   - Load 3 months data                │
        │   - Run indicators bar by bar         │
        └────────────────┬──────────────────────┘
                         │
                         │ SMC_Structure detects structures
                         │ Volumdelta calculates delta
                         ▼
        ┌───────────────────────────────────────┐
        │   SMC_RawExporter                     │
        │   - Combine indicators                │
        │   - Export raw JSONL                  │
        │   - 1 line per bar                    │
        └────────────────┬──────────────────────┘
                         │
                         ▼
                  raw_smc_export.jsonl
                  (100,000 bars)
                         │
                         ▼
        ┌───────────────────────────────────────┐
        │   Python: SMCDataProcessor            │
        │   - Load raw file                     │
        │   - Process each bar:                 │
        │     • Fix #1: OB score                │
        │     • Fix #2: FVG score               │
        │     • Fix #3: CHoCH score             │
        │     • Fix #4: Confluence              │
        │     • Fix #5-10: Other scores         │
        │   - Output BarState per bar           │
        └────────────────┬──────────────────────┘
                         │
                         ▼
                  bar_states.jsonl
                  (100,000 bars with scores)
                         │
                         ▼
        ┌───────────────────────────────────────┐
        │   Python: Event Detector              │
        │   - Scan BarStates                    │
        │   - Apply filters:                    │
        │     • confluence > 70                 │
        │     • market_condition > 0.7          │
        │     • session = London/NY             │
        │   - Detect setups                     │
        │   - Calculate entry/SL/TP             │
        └────────────────┬──────────────────────┘
                         │
                         ▼
                  event_states.jsonl
                  (5,000 events)
                         │
                         ▼
        ┌───────────────────────────────────────┐
        │   Python: Backtest                    │
        │   - Simulate each event               │
        │   - Track TP/SL hits                  │
        │   - Calculate metrics                 │
        │   - Label: win/loss                   │
        └────────────────┬──────────────────────┘
                         │
                         ▼
                  labeled_events.jsonl
                  (with outcomes)
                         │
                         ▼
        ┌───────────────────────────────────────┐
        │   Python: ML Training                 │
        │   - Load labeled events               │
        │   - Apply labeling strategy           │
        │   - Train DeepSeek model              │
        │   - Validate                          │
        │   - Save checkpoint                   │
        └────────────────┬──────────────────────┘
                         │
                         ▼
                  model_checkpoint.pt
                  (Trained model)

╔═════════════════════════════════════════════════════════════════╗
║                          LIVE TRADING                            ║
╚═════════════════════════════════════════════════════════════════╝
                            │
                            ▼
        ┌───────────────────────────────────────┐
        │   NinjaTrader Live Chart              │
        │   - Connect to broker                 │
        │   - Receive real-time ticks           │
        │   - Form M1 bars                      │
        └────────────────┬──────────────────────┘
                         │
                         │ OnBarClose event (every 1 min)
                         ▼
        ┌───────────────────────────────────────┐
        │   SMC_RawExporter (Live Mode)         │
        │   - Same as historical                │
        │   - Append to live_stream.jsonl       │
        │   - Ultra-fast (<10ms)                │
        └────────────────┬──────────────────────┘
                         │
                         ▼
                  live_stream.jsonl
                  (append mode, growing file)
                         │
                         ▼
        ┌───────────────────────────────────────┐
        │   Python Service (Running 24/7)       │
        │   - Watch live_stream.jsonl           │
        │   - Detect new line                   │
        │   - Read new bar                      │
        └────────────────┬──────────────────────┘
                         │
                         ▼
        ┌───────────────────────────────────────┐
        │   SMCDataProcessor (Live)             │
        │   - Same logic as training            │
        │   - Process new bar                   │
        │   - Calculate all scores              │
        │   - Takes ~50-100ms                   │
        └────────────────┬──────────────────────┘
                         │
                         ▼
                  bar_state (in memory)
                         │
                         ▼
        ┌───────────────────────────────────────┐
        │   Event Detection (Live)              │
        │   - Check: confluence > 70?           │
        │   - Check: filters pass?              │
        │   - If YES → Create event             │
        └────────────────┬──────────────────────┘
                         │
                         ▼ (Signal detected!)
                  event_state (in memory)
                         │
                         ├─────────────────────────────┐
                         │                             │
                         ▼                             ▼
        ┌────────────────────────────┐   ┌────────────────────────────┐
        │   ML Model Prediction      │   │   Risk Management Check    │
        │   - Load model_checkpoint  │   │   - Max positions: 3       │
        │   - Predict: "long"        │   │   - Daily loss limit: -5%  │
        │   - Confidence: 0.85       │   │   - Position size: 1%      │
        └─────────────┬──────────────┘   └─────────────┬──────────────┘
                      │                                 │
                      └────────────┬────────────────────┘
                                   │ (Both checks pass)
                                   ▼
        ┌───────────────────────────────────────┐
        │   Order Execution                     │
        │   - Create order                      │
        │   - Entry: 1.2345                     │
        │   - SL: 1.2300                        │
        │   - TP1: 1.2400 (50%)                 │
        │   - TP2: 1.2450 (50%)                 │
        │   - Send to broker via NT             │
        └────────────────┬──────────────────────┘
                         │
                         ▼
        ┌───────────────────────────────────────┐
        │   Trade Logging                       │
        │   - Save to trades.db                 │
        │   - Send Telegram notification        │
        │   - Update dashboard                  │
        └───────────────────────────────────────┘
```

---

## ⚡ COMPONENT TIMING

### Training Mode (Offline - No rush)

```
Historical Data Processing:
├─ Load 100k bars: ~2 seconds
├─ Process each bar:
│  ├─ Fix #1 (OB): ~0.1ms
│  ├─ Fix #2 (FVG): ~0.1ms
│  ├─ Fix #3-10: ~0.5ms
│  └─ Total per bar: ~0.7ms
├─ Process 100k bars: ~70 seconds
├─ Event detection: ~5 seconds
└─ Total: ~80 seconds for 100k bars ✅

This is FINE for offline processing!
```

### Live Trading (Real-time - Speed matters)

```
Per Bar (every 1 minute):

NinjaTrader Side:
├─ Bar close: 0ms (automatic)
├─ SMC structure detect: ~5ms
├─ Volume delta calc: ~2ms
├─ Export to file: ~3ms
└─ Total NT: ~10ms ✅ (very fast)

Python Side:
├─ Detect new line: ~10ms (polling)
├─ Read line: ~5ms
├─ Parse JSON: ~5ms
├─ Process bar (10 modules): ~50ms
├─ Event detection: ~10ms
├─ ML prediction: ~30ms
└─ Total Python: ~110ms ✅ (acceptable)

Overall latency: ~120ms from bar close to signal

This is EXCELLENT for M1 trading!
(You have 60 seconds until next bar)
```

---

## 🔄 REAL-TIME PROCESSING OPTIONS

### Option A: File-based (Recommended for start)

```
NinjaTrader → Write to file → Python watches file → Process

PROS:
✅ Simple
✅ Decoupled (NT crash ≠ Python crash)
✅ Can replay by re-reading file
✅ Easy to debug

CONS:
⚠️  Slight disk I/O delay (~10ms)
⚠️  Need file polling/watching
```

### Option B: Socket/API (Advanced)

```
NinjaTrader → Send via TCP socket → Python receives → Process

PROS:
✅ Faster (~5ms latency)
✅ No disk I/O
✅ Real-time streaming

CONS:
❌ More complex
❌ Need socket server
❌ Crash handling harder
```

### Option C: HTTP API (Enterprise)

```
NinjaTrader → POST to REST API → Python FastAPI server → Process

PROS:
✅ Industry standard
✅ Can scale (multiple instances)
✅ Load balancing possible
✅ Monitoring built-in

CONS:
❌ Most complex
❌ Overhead (~20ms)
❌ Need production server
```

**RECOMMENDATION for v1.0: Option A (File-based)**

---

## 💡 LIVE TRADING CHECKLIST

### Setup (One-time)

- [ ] Deploy Python service to server/cloud
- [ ] Configure NinjaTrader to export live
- [ ] Setup file watcher or polling
- [ ] Test connection between NT and Python
- [ ] Setup Telegram bot for alerts
- [ ] Configure risk management rules
- [ ] Prepare model checkpoint
- [ ] Test with paper trading first

### Daily Operations

**Morning (Before Market Open):**
- [ ] Check Python service is running
- [ ] Verify NT connection to broker
- [ ] Clear yesterday's log files
- [ ] Check disk space
- [ ] Review pending orders

**During Market Hours:**
- [ ] Monitor dashboard for signals
- [ ] Watch Telegram alerts
- [ ] Review trades in real-time
- [ ] Check system health metrics

**Evening (After Market Close):**
- [ ] Review day's trades
- [ ] Check win rate
- [ ] Analyze any losses
- [ ] Update model if needed
- [ ] Backup data

---

## 📱 TELEGRAM ALERT EXAMPLE

```
🚨 TRADING SIGNAL DETECTED

Time: 2025-11-20 10:31:00 ET
Symbol: 6E (EUR/USD)
Timeframe: M1

Signal: OB Retest Bull 🟢
Direction: LONG

Scores:
├─ OB Strength: 0.88 ⭐
├─ Confluence: 85.2 ⭐
├─ Market Condition: 0.92 ⭐
└─ Volume Divergence: 0.65

Entry: 1.2345
Stop Loss: 1.2300 (-45 ticks)
TP1: 1.2400 (+55 ticks) [50%]
TP2: 1.2450 (+105 ticks) [50%]
Risk/Reward: 1:2.6

ML Prediction: LONG (confidence: 0.85)

Action Needed:
[ Manual Review ] or [ Auto-trade ]

View Chart: [Link to TradingView]
```

---

## 🎯 SUMMARY

### Training (Offline):
1. NinjaTrader exports RAW data (FVG boundaries, volume, delta)
2. Python processes with 11 modules (FVG Quality v2.0 is CORE)
3. **FVG retest events ONLY** detected and labeled
4. Model learns: FVG retest → long/short/skip
✅ **Can take hours - it's okay!**

### Live Trading (Real-time):
1. NinjaTrader exports raw data (live)
2. Python processes with FVG Quality v2.0:
   - Strength classification
   - Retest geometry evaluation
   - Adaptive entry calculation
3. **FVG retest signals** generated if quality high
4. ML model predicts
5. Order placed (auto or manual)
✅ **Takes ~120ms - perfect for M1!**

### Key Design Principles (v2.0):
- **FVG is the ONLY signal type** - OB/CHoCH are context ONLY
- **Layer 1 (Ninja) = RAW** - No scoring in C#
- **Layer 2 (Python) = SMART** - All quality logic here
- **Penetration > 50% = SKIP** - Critical filter rule
- **Strong FVG + Edge touch = BEST** - Highest probability setup

### Key Insight:
**Same code for both!** Training mode = batch process, Live mode = streaming process

---

**Version:** 2.0.0
**Last Updated:** November 21, 2025
