# Package initializer for Layer 2 processor.
