# Core utilities and shared data structures.
